// const sequelize = require('../db')
// const {DataTypes} = require('sequelize')
//
// const User = sequelize.define('user', {
//   id: {type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true},
//   email: {type: DataTypes.STRING, unique: true,},
//   password: {type: DataTypes.STRING},
//   role: {type: DataTypes.STRING, defaultValue: "USER"},
// })
//
// const Cart = sequelize.define('cart', {
//   id: {type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true},
// })
//
// const CartService = sequelize.define('cart_service', {
//   id: {type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true},
// })
//
// const Service = sequelize.define('service', {
//   id: {type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true},
//   name: {type: DataTypes.STRING, unique: true, allowNull: false},
//   price: {type: DataTypes.INTEGER, allowNull: false},
//   rating: {type: DataTypes.INTEGER, defaultValue: 0},
//   img: {type: DataTypes.STRING, allowNull: false},
// })
//
// const Type = sequelize.define('type', {
//   id: {type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true},
//   name: {type: DataTypes.STRING, unique: true, allowNull: false},
// })
//
// const Rating = sequelize.define('rating', {
//   id: {type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true},
//   rate: {type: DataTypes.INTEGER, allowNull: false},
// })
//
// const ServiceInfo = sequelize.define('service_info', {
//   id: {type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true},
//   title: {type: DataTypes.STRING, allowNull: false},
//   description: {type: DataTypes.STRING, allowNull: false},
// })
//
// const TypeBrand = sequelize.define('type_brand', {
//   id: {type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true},
// })
//
//
// User.hasOne(Cart)
// Cart.belongsTo(User)
//
// User.hasMany(Rating)
// Rating.belongsTo(User)
//
// Cart.hasMany(CartService)
// CartService.belongsTo(Cart)
//
// Type.hasMany(Service)
// Service.belongsTo(Type)
//
// Service.hasMany(Rating)
// Rating.belongsTo(Service)
//
// Service.hasMany(CartService)
// CartService.belongsTo(Service)
//
// Service.hasMany(ServiceInfo, {as: 'info'});
// ServiceInfo.belongsTo(Service)
//
// module.exports = {
//   User,
//   Cart,
//   CartService,
//   Service,
//   Type,
//   Rating,
//   ServiceInfo
// }